from flask import Flask,render_template,request
import os
import settings
import pandas as pd
import requests
import json

app = Flask(__name__,static_url_path='/static')


@app.route('/lanes', methods=['GET', 'POST'])
def show_lanes():
    rootdir = os.path.dirname(os.path.realpath(__file__))
    csv_file = rootdir + "/CSVFILES/" + settings.CSVFILE
    data = pd.read_csv(csv_file)
    lane_data = list(set(data['Plan_Lane']))

    return render_template('lanes.html', lane_data=lane_data)

@app.route('/rating_options', methods=['GET', 'POST'])
def carrier_rating_options():
    results = {}
    errors = []
    if request.method == "GET":
        return render_template('options.html')
    if request.method == "POST":
        selected_rating_option = request.form.get("rating")
        if selected_rating_option != None:
            try:
                data = requests.get('http://127.0.0.1:5000/CarrierAPI/Rating/carrier/'+str(selected_rating_option))
            except:
                errors.append(
                    "Unable to get URL. Please make sure it's valid and try again."
                )
                return render_template('options.html', errors=errors, results=results)

            if data.status_code != 200:
                errors.append(
                    "Unable to get URL. Please make sure it's valid and try again."
                )
                return render_template('options.html', errors=errors, results=results)

            api_data = json.loads(data.text)
            val_list = []
            load_value = None
            for key, values in api_data.items():
                for list_val in values:
                    for load_key,load_val in list_val.items():
                        if load_key == 'LOAD':
                            load_value = load_val
                            results.setdefault(load_value,[])
                        else:
                            val_list.append(load_val)
                    results.setdefault(load_value).append(val_list)
                    val_list = []
        return render_template('options.html',errors=errors, results=results)

if __name__ == '__main__':
    app.run(port=8080)
